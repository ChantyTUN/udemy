<!DOCTYPE html>
<html>
<head>
	<title>Mail from ABC company</title>
</head>
<body>
<p><?php echo e($details['body']); ?></p>
<p>Thank you</p>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/employee/resources/views/admin/email/sendmail.blade.php ENDPATH**/ ?>