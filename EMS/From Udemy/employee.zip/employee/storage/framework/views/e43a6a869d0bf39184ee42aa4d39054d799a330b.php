<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">All Leave</div>

                <div class="card-body">
                    <table class="table mt-5"  id="dataTable">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Date from</th>
                  <th scope="col">Date To</th>
                  <th scope="col">Description</th>
                <th scope="col">type</th>
                  <th scope="col">Reply</th>
                  <th scope="col">Status</th>
               
                <th scope="col">Approve/Reject</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td> <?php echo e($leave->user->name); ?></td>
                  <td><?php echo e($leave->from); ?></td>
                  <td><?php echo e($leave->to); ?></td>
                  <td><?php echo e($leave->description); ?></td>
                  <td><?php echo e($leave->type); ?></td>
                  <td><?php echo e($leave->message); ?></td>
                  <td>
                      <?php if($leave->status==0): ?>
                      <span class="alert alert-danger">pending</span>
                      <?php else: ?>
                      <span class="alert alert-success">Approved</span>
                      <?php endif; ?>
                  </td>
                  
                  <td>
                      <a href="#" data-toggle="modal" data-target="#exampleModal<?php echo e($leave->id); ?>">
                       Approve/Reject
                    </a>
                      <!-- Modal -->
                <div class="modal fade" id="exampleModal<?php echo e($leave->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <form action="<?php echo e(route('accept.reject',[$leave->id])); ?>" method="post"><?php echo csrf_field(); ?>
                        
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"> Confirm Leave</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                      <div class="form-group">
                          <label>Status</label>
                          <select class="form-control" name="status" required="">
                              <option value="0">Pending</option>
                              <option value="1">Accept</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <label>Status</label>
                   <textarea name="message" class="form-control" required=""></textarea>
                        </div>
                       

                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Submit</button>
                      </div>
                    </div>
                  </form>
                  </div>
                </div>
                <!--Modal end-->
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </tbody>
            </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/employee/resources/views/admin/leave/index.blade.php ENDPATH**/ ?>