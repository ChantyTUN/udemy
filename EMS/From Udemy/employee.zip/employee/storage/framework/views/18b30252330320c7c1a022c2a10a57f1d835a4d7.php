<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card">
        <div class="card-header">Roles</div>

<div class="card-body">
 <select name="role_id" class="form-control">
                        <option value="">Please select a role</option>
                        <?php $__currentLoopData = App\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger">
                              <?php echo e($message); ?>

                          </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <table class="table table-bordered table-dark">
                    <thead>
                    <tr>
                        <th>Permission</th>
                        <th>Can-add</th>
                        <th>Can-edit</th>
                        <th>Can-view</th>
                        <th>Can-delete</th>
                        <th>Can-list</th>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                        <td>Roles</td>
                        <td><input type="checkbox" name="name[role][can-create]" value="1"></td>
                        <td><input type="checkbox" name="name[role][can-edit]" value="1"></td>
                        <td><input type="checkbox" name="name[role][can-view]" value="1"></td>
                        <td><input type="checkbox" name="name[role][can-delete]" value="1"></td>
                        <td><input type="checkbox" name="name[role][can-]" value="1"></td>

                    </tr>
                  
                    </tbody>
                </table>
            </div>
        </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/employee/resources/views/admin/create.blade.php ENDPATH**/ ?>