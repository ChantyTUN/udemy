<!DOCTYPE html>
<html>
<head>
    <title>Real Programmer</title>
</head>
<body>
    <h1></h1>
    <p><?php echo e($details['body']); ?></p>
    <p>Thank you</p>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/employee/resources/views/admin/emails/sendmail.blade.php ENDPATH**/ ?>