@include('admin.layouts.navbar')
@include('admin.layouts.sidebar')
@include('admin.layouts.content')
@include('admin.layouts.fotter')