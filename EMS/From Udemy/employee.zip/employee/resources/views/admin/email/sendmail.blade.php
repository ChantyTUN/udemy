<!DOCTYPE html>
<html>
<head>
	<title>Mail from ABC company</title>
</head>
<body>
<p>{{$details['body']}}</p>
<p>Thank you</p>
</body>
</html>