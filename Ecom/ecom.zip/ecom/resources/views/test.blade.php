@extends('admin.layouts.main')

@section('content')

form goes here...

@endsection