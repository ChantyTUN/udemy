<?php $__env->startSection('content'); ?>


    <div class="container">
        <h2>Products</h2>

      <div class="row">
        <div class="col-md-2">
             <form action="<?php echo e(route('product.list',[$slug])); ?>" method="GET">
            <!--foreach subcategories-->
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
              <p><input type="checkbox" name="subcategory[]"
               value="<?php echo e($subcategory->id); ?>"
               <?php if(isset($filterSubCategories)): ?>
                <?php echo e(in_array($subcategory->id,$filterSubCategories)?'checked ="checked" ':''); ?>

               <?php endif; ?>

               ><?php echo e($subcategory->name); ?></p>
           <!--end foreach-->
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <input type="submit" value="Filter" class="btn btn-secondary">
         </form>
         <hr>
         <h3>Filter by price</h3>

         <form  action="<?php echo e(route('product.list',[$slug])); ?>" method="GET">
             <input type="text" name="min" class="form-control" placeholder="minimum price" required="">
            <br>
             <input type="text" name="max" class="form-control" placeholder="maximum price" required=""  >
             <input type="hidden" name="categoryId" value="<?php echo e($categoryId); ?>">
             
             <br>
             <br>
            <input type="submit" value="Filter" class="btn btn-secondary">

        </form>
       <hr>
       <a href="<?php echo e(route('product.list',[$slug])); ?>">Back</a>

      



        </div>
      <div class="col-md-10">
        <div class="row">
      <!--foreach products-->
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="<?php echo e(Storage::url($product->image)); ?>" height="200" style="width: 100%">
            <div class="card-body">
                <p><b><?php echo e($product->name); ?> </b></p>
              <p class="card-text">
                <?php echo e((Str::limit($product->description,120))); ?>

              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                 <a href="<?php echo e(route('product.view',[$product->id])); ?>"> <button type="button" class="btn btn-sm btn-outline-success">View</button>
                 </a>
               <a href="<?php echo e(route('add.cart',[$product->id])); ?>">   <button type="button" class="btn btn-sm btn-outline-primary">Add to cart</button>
               </a>
                </div>
                <small class="text-muted">$<?php echo e($product->price); ?></small>
              </div>
            </div>
          </div>
        </div>
    <!--endforeach-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
</div>
</div>

      
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom/resources/views/category.blade.php ENDPATH**/ ?>