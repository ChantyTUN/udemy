<?php $__env->startSection('content'); ?>

        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Order Tables</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Order</li>
              <li class="breadcrumb-item active" aria-current="page">Order Tables</li>
            </ol>
          </div>

           	<div class="row justify-content-center">
 		<div class="col-md-8">
 			<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 			<div class="card mb-3">
 				<div class="card-body">
 					<?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 					<span class="float-right">
 						<img src="<?php echo e(Storage::url($item['image'])); ?>" width="100">
 					</span>

 					<p>Name:<?php echo e($item['name']); ?></p>
 					<p>Price:<?php echo e($item['price']); ?></p>
 					<p>Qty:<?php echo e($item['qty']); ?></p>


 					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					
 				</div>

 			</div>

 			<p>
 				<button type="button" class="btm btn-success">
 					<span class="">
 						Total price:$<?php echo e($cart->totalPrice); ?>

 					</span>
 				</button>
 			</p>
 			
 			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 		</div>
 	</div>



 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom/resources/views/admin/order/show.blade.php ENDPATH**/ ?>