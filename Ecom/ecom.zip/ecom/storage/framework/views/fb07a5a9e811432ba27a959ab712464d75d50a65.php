<?php $__env->startSection('content'); ?>

 <div class="container">
 	<form action="<?php echo e(route('more.product')); ?>" method="GET">
 		<div class="form-row">
 			<div class="col-md-8">
 				<input type="text" name="search" class="form-control" placeholder="search...">
 			</div>
 			<div class="col">
 				<button type="submit" class="btn btn-secondary">Search</button>
 			</div>
 		</div>

 	</form>
 	<br>


 	     <div class="row">
      
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="<?php echo e(Storage::url($product->image)); ?>" height="200" style="width: 100%">
            <div class="card-body">
                <p><b><?php echo e($product->name); ?></b></p>
              <p class="card-text">
                  <?php echo e((Str::limit($product->description,120))); ?>

              </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                 <a href="<?php echo e(route('product.view',[$product->id])); ?>"> <button type="button" class="btn btn-sm btn-outline-success">View</button>
                 </a>
                 <a href="<?php echo e(route('add.cart',[$product->id])); ?>"> <button type="button" class="btn btn-sm btn-outline-primary">Add to cart</button></a>
                </div>
                <small class="text-muted">$<?php echo e($product->price); ?></small>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php echo e($products->links()); ?>


 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom/resources/views/all-product.blade.php ENDPATH**/ ?>