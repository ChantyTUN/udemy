<?php $__env->startSection('content'); ?>

 <div class="container">
 	
 	<div class="row justify-content-center">
 		<div class="col-md-8">
 			<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 			<div class="card mb-3">
 				<div class="card-body">
 					<?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 					<span class="float-right">
 						<img src="<?php echo e(Storage::url($item['image'])); ?>" width="100">
 					</span>

 					<p>Name:<?php echo e($item['name']); ?></p>
 					<p>Price:<?php echo e($item['price']); ?></p>
 					<p>Qty:<?php echo e($item['qty']); ?></p>

 					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					
 				</div>

 			</div>
 			<p>
 				<button type="button" class="btm btn-info" style="color: #fff;">
 					<span class="">
 						Total price:$<?php echo e($cart->totalPrice); ?>

 					</span>
 				</button>
 			</p>
 			<hr>
 			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 		</div>
 	</div>
 	


 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom/resources/views/order.blade.php ENDPATH**/ ?>