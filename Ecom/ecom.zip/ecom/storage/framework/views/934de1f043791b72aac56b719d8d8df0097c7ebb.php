
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
      <th scope="col">Qty</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row">1</th>
      <td><?php echo e($product['name']); ?></td>
      <td><?php echo e($product['price']); ?></td>
      <td>{{$product['qty']}}</td>

    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr>
    	Total Price:<?php echo e($cart->totalPrice); ?>

    	Please check your order<a href="<?php echo e(url('/orders')); ?>">Click here</a>
    </tr>
   
  </tbody>
</table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom/resources/views/emails/sendmail.blade.php ENDPATH**/ ?>