<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 ml-4 text-gray-800">Product</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Product</li>
            </ol>
    </div>
    <!-- Datatables -->
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Products</h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush" id="dataTable">
                    <thead class="thead-light">
                      <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Additional_info</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th></th>
                        <th></th>
                        
                      </tr>
                    </thead>
                    
                    <tbody>
                      <?php if(count($products)>0): ?>
                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>
                          <img src="<?php echo e(Storage::url($product->image)); ?>" width="100">
                        </td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo $product->description; ?></td>
                        <td><?php echo $product->additional_info; ?></td>
                        <td>$<?php echo e($product->price); ?></td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td>
                          <a href="<?php echo e(route('product.edit',[$product->id])); ?>">
                              <button class="btn btn-primary">Edit</button>
                          </a>
                        </td>
                        <td>
                           <form action="<?php echo e(route('product.destroy',[$product->id])); ?>" method="POST" onsubmit="return confirmDelete()"><?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-sm btn-danger" >Delete</button>
                            
                          </form>
                        </td>

                         
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                      <td>No any product</td>
                      <?php endif; ?>
                    

                    </tbody>
                  </table>
                </div>
              </div>
            </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom/resources/views/admin/product/index.blade.php ENDPATH**/ ?>